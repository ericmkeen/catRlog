#########################################################
#########################################################
# catRlog  | Eric M. Keen, v. July 2020
#########################################################
# Function to gather up all quality scores currently in catRlog directory

gather.quality.scores <- function(){
  log <- data.frame() ; log
  scoredir <- "../2 scores/score sessions/"
  
  lf <- list.files(scoredir) ; lf
  if(length(lf)>0){
    lf <- paste0(scoredir,lf) ; lf
    i=1
    log <- data.frame()
    for(i in 1:length(lf)){
      lfi <- lf[i] ; lfi
      mri <- read.csv(lfi,stringsAsFactors=FALSE,header=FALSE) ; mri
      log <- rbind(log,mri)
    }
    names(log) <- c("time","analyst","event","img","path","angle","focus","exposure","visible","distinct","calf","parasites")
    head(log)
    
    # Remove NAs
    head(log) ; nrow(log)
    log <- log[!is.na(log$path),]
    nrow(log) ; head(log)
  }
  
  return(log)
}

#log <- gather.quality.scores() ; nrow(log)
#head(log)

#########################################################
# Function to check for photograph quality scores for a sighting event

find.quality.score <- function(log,epath){
  #epath <- "../0 photos/photos/2015 Elemiah/2015-06-21_2945.JPG"
  ematch <- which(log$path == epath) ; ematch
  scores <- data.frame()
  distinct <- quality <- NA
  if(length(ematch)){
    scores <- log[ematch[1],] ; scores
    distinct <- scores$distinct
    scori <- scores[6:9] ; scori
    if(any(scori==3)){
      quality <- 3
    }else{
      if(any(scori==2) & any(scori==1)){
        quality <- 12
      }else{
        if(all(scori==2)){quality <- 2}
        if(all(scori==1)){quality <- 1}
      }
    }
  }
  return(list(score=quality,distinct=distinct,row=scores))
}
 

#########################################################
#########################################################
