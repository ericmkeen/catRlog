#########################################################
#########################################################
# catRlog  | Eric M. Keen, v. July 2020
#########################################################
# Function
#########################################################
#########################################################

# Set working directory to folder that this R file is in
#setwd(dirname(rstudioapi::getActiveDocumentContext()$path))


testdata <- FALSE
if(testdata){
  
  # Set working directory to folder that this R file is in
  setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
  ilv <- compile.ILV()
  dyads <- compile.dyads(ilv)
  
  var="sri"
  
}

#########################################################
#########################################################

association.matrix <- function(dyads,var){
    head(dyads)
    data <- dyads
    X <- data[,which(names(data)==var)] ; X
    
    MAT <- matrix(data = X, 
                  nrow = length(unique(data$A)), 
                  ncol = length(unique(data$A)),
                  byrow = FALSE,
                  dimnames = list(unique(data$A),unique(data$A)))
    MAT[1:6,1:6]
    
    library(igraph)
    gmat <- MAT
    diag(gmat) <- 0
    g=graph.adjacency(gmat,mode="undirected",weighted=TRUE)
    return(list(g=g,mx=MAT))
}

#g <- association.matrix(dyads,var)
#g <- g$g
#plot(g)


#########################################################
#########################################################
