#########################################################
#########################################################
# catRlog  | Eric M. Keen, v. July 2020
#########################################################
# Function
#########################################################
#########################################################
# Load all necessary packages

if(! "devtools" %in% rownames(installed.packages())){install.packages("devtools")}
if(! "shiny" %in% rownames(installed.packages())){install.packages("shiny")}
if(! "DT" %in% rownames(installed.packages())){install.packages("DT")}
if(! "pander" %in% rownames(installed.packages())){install.packages("pander")}
if(! "glue" %in% rownames(installed.packages())){install.packages("glue")}
if(! "imager" %in% rownames(installed.packages())){
  install.packages("imager")
  #devtools::install_github("dahtah/imager")
}
if(! "assocInd" %in% rownames(installed.packages())){install.packages("assocInd")}
#if(! "rootSolve" %in% rownames(installed.packages())){install.packages("rootSolve")}
if(! "fields" %in% rownames(installed.packages())){install.packages("fields")}
if(! "exifr" %in% rownames(installed.packages())){install.packages("exifr")}
if(! "exiftoolr" %in% rownames(installed.packages())){install.packages("exiftoolr")}
if(! "igraph" %in% rownames(installed.packages())){install.packages("igraph")}

library(shiny)
library(DT)
library(pander)
library(imager)
library(assocInd)
#library(rootSolve)
library(igraph)
library(fields)
library(exifr)
library(exiftoolr)
#install_exiftool()






