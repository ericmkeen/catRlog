#########################################################
#########################################################
# Source all function files
# Eric Keen, v. June 2020

# Set working directory to folder that this R file is in
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

#########################################################
#########################################################

# Get list of R files that contain functions
lf <- list.files()
funks <- grep("function",lf) ; funks
lfunk <- lf[funks] ; lfunk
lfunk <- lfunk[-grep("00",lfunk)] ; lfunk

# Loop through each function file and source it
if(length(lfunk)>0){
  i=1
  for(i in 1:length(lfunk)){
    lfi <- lfunk[i] ; print(lfi)
    source(lfi)
  }
}

#########################################################
#########################################################
