#########################################################
#########################################################
# catRlog  | Eric M. Keen, v. July 2020
#########################################################
# Function - Compile ILV dataset
#########################################################
#########################################################

# Set working directory to folder that this R file is in
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

#########################################################
#########################################################

testdata <- FALSE
if(testdata){
  
  # Set working directory to folder that this R file is in
  setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
  source("function-eventlog.R")
  source("function-groups.R")
  source("function-ILV.R")
  events <- compile.events()
  groups <- compile.groups(events)
  ILV <- compile.ILV(events)
  samp.period <- "year"
}

#########################################################
#########################################################

caphist <- function(ILV,groups,samp.period="year"){
  # Sample period options
  # year
  # platform
  # py
  
  head(groups)
  groups$sp <- groups[,which(names(groups)==samp.period)]
  sps <- unique(groups$sp) ; sps

  mr <- ILV ; head(mr)
  
  chs <- c()
  i=1
  for(i in 1:nrow(mr)){
    mri <- mr[i,] ; mri
    gids <- strsplit(as.character(mri$groups)," ")[[1]] ; gids
    groupi <- groups[as.character(groups$groupid) %in% gids,] ; groupi
    spi <- unique(groupi$sp) ; spi
    
    chi <- c()
    j=1
    for(j in 1:length(sps)){
      spj <- sps[j] ; spj
      if(spj %in% spi){chj <- 1}else{chj <- 0}
      chi <- c(chi,chj)
    }
    chi
    chi <- paste(chi,collapse="") ; chi
    chs <- c(chs,chi)
  }
  chs
  
  head(mr)
  df <- data.frame(ch=chs,mr[,1:9]) ; head(df)
  
  return(df)
}


#########################################################
#########################################################
